const darkmenu = (prefix) => {
	return `

            COMANDOS:


  *Comandos do Sozin:*

➸ *${prefix}loli*
➸ *${prefix}hentai*
➸ *${prefix}dono*
➸ *${prefix}porno*
➸ *${prefix}boanoite*
➸ *${prefix}bomdia*
➸ *${prefix}boatarde*
➸ *${prefix}mia*
➸ *${prefix}mia1*
➸ *${prefix}mia2*
➸ *${prefix}belle*
➸ *${prefix}belle1*
➸ *${prefix}belle2*
➸ *${prefix}belle3*
➸ *${prefix}ayeko*

╔════════════════════
  TRADUZIDO POR *Sozin*
  DUVIDAS? 👇
  Wa.me/+351925955554 Wa.me/+553899063625
╚════════════════════`
}

exports.darkmenu = sozinmenu









